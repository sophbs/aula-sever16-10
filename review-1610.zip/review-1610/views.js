function layout(title, content) {
    return /* html */ `
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}t</title>
</head>
<body>
    <nav>
       <a href="/">home</a></nav>
       <a href="/products">products</a></nav>
       <a href="/about">about</a>
       </nav>
    ${content}
</body>
</html>
    `
}

export function homePage() {
    return layout("home", "<h1>Welcome to the server!</h1>")
}
export function aboutPage() {
    return layout("About", "<h1>About the server!</h1>")
}
export function notFoundPage() {
    return layout("404", "<h1>Not Found - 404</h1>")
}

const products = [
    {name: "Teclado", price:150 },
    {name: "Mouse", price:800},
    {name: "Monitor", price:900 }
]
export function productsPage() {
    const rows = products.map((products) => {
        return (/* html */ `
        <tr>
            <td>${products.name}</td>
            <td>${products.price}</td>
        <tr>
        `)
    })
    return layout("Products", "<h1>Página de produtos!</h1>")
}
