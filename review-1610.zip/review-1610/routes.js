import { aboutPage, homePage, productsPage, notFoundPage } from "./views.js"

export function Route(req, res) {
    console.log(req);

    if (req.url === "/" && req.method === "GET") {
        res.writeHead(200, { "Content-Type": "text/html" })
        res.end(homePage())
        return
    }
    if (req.url === "/about" && req.method === "GET") {
        res.writeHead(200, { "Content-Type": "text/html" })
        res.end(aboutPage())
        return
    }
    if (req.url === "/products" && req.method === "GET") {
        res.writeHead(200, { "Content-Type": "text/html" })
        res.end(productsPage())
        return
    }
    
    res.whiteHead(404, {"Content-Type": "text/html"})
    res.end("<h1>Page Not Found - 404</h1>")
}
