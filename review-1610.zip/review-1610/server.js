import http from "http"
import { Route } from "./routes.js"

const PORT = 3000
const server = http.createServer(Route)

server.listen(3000, () => {
    console.log("server running in http://localhost:3000");
    
})