let nome = "Maria José da Silva"
let height = 1.87
let pets = ["dog", "cat", "catdog", "bunny"]

console.log(typeof nome);
console.log(typeof height);
console.log(typeof pets);

pets.forEach((pet, i) => console.log(pet, i))

let petsAndChocolate = pets.map((pet) => pet + "chocolate")